namespace EgorPlugin.Utilites.SpecialEntity.RedType;

public class RedTypeAbility     
{
    
}