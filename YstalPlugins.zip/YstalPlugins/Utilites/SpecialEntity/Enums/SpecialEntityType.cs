namespace YstalPlugins.Utilites.SpecialEntity.Enums;

public enum SpecialEntityType
{
    Green,
    Red,
    Grey
}