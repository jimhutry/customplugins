using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using CommandSystem;
using Exiled.Permissions.Extensions;
using MEC;
using YstalPlugins.Utilites.SpecialEntity.Enums;

namespace YstalPlugins.Utilites.SpecialEntity.OperationalSpecialEntity;

public class SetSpecialEntityCommand : ICommand, IUsageProvider, IHelpProvider
{

    public string Command { get; } = "set";
    public string[] Aliases { get; } = [];
    public string Description { get; } = "";
    public string[] Usage { get; } = ["player_id", "entity_type"];
    public Dictionary<Player, int> RedType = [];
    
    public bool Execute(ArraySegment<string> arguments, ICommandSender sender, [UnscopedRef] out string response)
    {
        if (!sender.CheckPermission("rp.playerutils"))
        {
            response = "Нет прав.";
            return false;
        }

        if (arguments.Count < 1 || !int.TryParse(arguments.At(0), out int id))
        {
            response = GetHelp(arguments);
            return true;
        }

        if (!Enum.TryParse(arguments.At(1), out SpecialEntityType type))
        {
            response = "<b>Типы сущностей (читайте лор):</b> Green, Grey, Red.";
            return true;
        }
        // ReSharper disable once SwitchStatementHandlesSomeKnownEnumValuesWithDefault
        switch (type)
        {
            case SpecialEntityType.Grey:
                response = "grey";
                return true;
            case SpecialEntityType.Green:
                response = "green";
                return true;
            case SpecialEntityType.Red:
                if (arguments.Count < 3 || !int.TryParse(arguments.At(2), out int powerLevel))
                {
                    response = "<b>Помощь по использованию:</b> specialentity set Red power(0-3)";
                    return false;
                }

                switch (GlobalProjectFunctions.Clamp(powerLevel, 0, 3))
                {
                    case 0:
                        RedType[Player.Get(id)] = powerLevel;
                        Timing.RunCoroutine(ZeroPowerCoroutine(Player.Get(id)), Segment.RealtimeUpdate,
                            nameof(ZeroPowerCoroutine));
                        break;
                    case 1:
                        RedType[Player.Get(id)] = powerLevel;
                        Timing.RunCoroutine(OnePowerCoroutine(Player.Get(id)), Segment.RealtimeUpdate,
                            nameof(OnePowerCoroutine));
                        break;
                    case 2:
                        RedType[Player.Get(id)] = powerLevel;
                        Timing.RunCoroutine(TwoPowerCoroutine(Player.Get(id)), Segment.RealtimeUpdate,
                            nameof(TwoPowerCoroutine));
                        break;
                    case 3:
                        RedType[Player.Get(id)] = powerLevel;
                        Timing.RunCoroutine(ThreePowerCoroutine(Player.Get(id)), Segment.RealtimeUpdate,
                            nameof(ThreePowerCoroutine));
                        break;
                }
                
                response = "red";
                break;
        }
        response = "a";
        return true;
    }

    private static IEnumerator<float> ZeroPowerCoroutine(Player plr)
    {
        
    }
    private static IEnumerator<float> OnePowerCoroutine(Player plr)
    {
        
    }
    private static IEnumerator<float> TwoPowerCoroutine(Player plr)
    {
        
    }
    private static IEnumerator<float> ThreePowerCoroutine(Player plr)
    {
        
    }
    public string GetHelp(ArraySegment<string> arguments)
        {
            return $"<b>Помощь по использованию:</b> specialentity set {this.DisplayCommandUsage()}";
        }
    }
    