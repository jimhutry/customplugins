using System;
using System.Diagnostics.CodeAnalysis;
using CommandSystem;

namespace EgorPlugin.Utilites;

public class RemoveSpecialEntityCommand : ICommand
{
    public bool Execute(ArraySegment<string> arguments, ICommandSender sender, [UnscopedRef] out string response)
    {
        throw new NotImplementedException();
    }

    public string Command { get; }
    public string[] Aliases { get; }
    public string Description { get; }
}